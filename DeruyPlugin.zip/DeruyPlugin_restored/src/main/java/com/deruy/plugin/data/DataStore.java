package com.deruy.plugin.data;

import com.deruy.plugin.DeruyPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * config.yml과 분리된 런타임 상태 저장소. 커맨드로 계속 바뀌는 데이터
 * (KOTH 구역 좌표, 빙고 팀 배정, 바운티 페어, 서플라이드랍 구역)를 여기 담는다.
 * 파일: plugins/DeruyPlugin/data.yml
 */
public class DataStore {

    private final DeruyPlugin plugin;
    private final File file;
    private YamlConfiguration data;

    public DataStore(DeruyPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        load();
    }

    private void load() {
        if (!file.exists()) {
            try {
                file.getParentFile().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("data.yml 생성 실패: " + e.getMessage());
            }
        }
        data = YamlConfiguration.loadConfiguration(file);
    }

    public void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("data.yml 저장 실패: " + e.getMessage());
        }
    }

    // ---------------- 좌표 직렬화 헬퍼 ----------------

    private void writeLocation(String path, Location loc) {
        data.set(path + ".world", loc.getWorld().getName());
        data.set(path + ".x", loc.getX());
        data.set(path + ".y", loc.getY());
        data.set(path + ".z", loc.getZ());
    }

    private Location readLocation(String path) {
        if (!data.isConfigurationSection(path)) return null;
        String worldName = data.getString(path + ".world");
        World world = worldName != null ? Bukkit.getWorld(worldName) : null;
        if (world == null) return null;
        double x = data.getDouble(path + ".x");
        double y = data.getDouble(path + ".y");
        double z = data.getDouble(path + ".z");
        return new Location(world, x, y, z);
    }

    // ---------------- KOTH 구역 ----------------

    public void saveKothZone(String id, Location corner1, Location corner2) {
        if (corner1 != null) writeLocation("koth.zones." + id + ".corner1", corner1);
        if (corner2 != null) writeLocation("koth.zones." + id + ".corner2", corner2);
        save();
    }

    public void removeKothZone(String id) {
        data.set("koth.zones." + id, null);
        save();
    }

    /** id -> [corner1, corner2] (둘 중 하나가 null일 수 있음) */
    public Map<String, Location[]> loadKothZones() {
        Map<String, Location[]> result = new HashMap<>();
        ConfigurationSection zonesSection = data.getConfigurationSection("koth.zones");
        if (zonesSection == null) return result;

        for (String id : zonesSection.getKeys(false)) {
            Location c1 = readLocation("koth.zones." + id + ".corner1");
            Location c2 = readLocation("koth.zones." + id + ".corner2");
            result.put(id, new Location[]{c1, c2});
        }
        return result;
    }

    // ---------------- 빙고 팀 배정 ----------------

    public void saveBingoTeam(UUID playerId, String team) {
        data.set("bingo.teams." + playerId, team);
        save();
    }

    public Map<UUID, String> loadBingoTeams() {
        Map<UUID, String> result = new HashMap<>();
        ConfigurationSection section = data.getConfigurationSection("bingo.teams");
        if (section == null) return result;

        for (String key : section.getKeys(false)) {
            try {
                result.put(UUID.fromString(key), section.getString(key));
            } catch (IllegalArgumentException ignored) {
            }
        }
        return result;
    }

    // ---------------- 바운티 페어 ----------------

    public void saveBountyPair(UUID a, UUID b) {
        data.set("bounty.pairs." + a, b.toString());
        data.set("bounty.pairs." + b, a.toString());
        save();
    }

    public void removeBountyPair(UUID a) {
        String other = data.getString("bounty.pairs." + a);
        data.set("bounty.pairs." + a, null);
        if (other != null) {
            data.set("bounty.pairs." + other, null);
        }
        save();
    }

    public Map<UUID, UUID> loadBountyPairs() {
        Map<UUID, UUID> result = new HashMap<>();
        ConfigurationSection section = data.getConfigurationSection("bounty.pairs");
        if (section == null) return result;

        for (String key : section.getKeys(false)) {
            try {
                result.put(UUID.fromString(key), UUID.fromString(section.getString(key)));
            } catch (IllegalArgumentException ignored) {
            }
        }
        return result;
    }

    // ---------------- 서플라이드랍 구역 (일반/슈퍼 공용) ----------------

    public void saveSupplyRegion(String kind, Location corner1, Location corner2) {
        if (corner1 != null) writeLocation("supplydrop." + kind + ".corner1", corner1);
        if (corner2 != null) writeLocation("supplydrop." + kind + ".corner2", corner2);
        save();
    }

    /** [corner1, corner2] 반환, 설정 안 됐으면 null */
    public Location[] loadSupplyRegion(String kind) {
        Location c1 = readLocation("supplydrop." + kind + ".corner1");
        Location c2 = readLocation("supplydrop." + kind + ".corner2");
        if (c1 == null || c2 == null) return null;
        return new Location[]{c1, c2};
    }
}
